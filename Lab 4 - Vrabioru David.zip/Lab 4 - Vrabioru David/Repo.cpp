#include "Repo.h"

Repo::Repo()
{
}



void Repo::addItem(GymExercise ge)
{
	elem.push_back(ge);
}

void Repo::delElem(GymExercise ge)
{
	vector<GymExercise>::iterator it;
	it = find(elem.begin(), elem.end(), ge);
	if (it != elem.end()) elem.erase(it);
}


void Repo::updateElem(GymExercise ge, char* name, int nos, int nor, float weight)
{
	for (int i = 0; i < elem.size(); i++)
	{
		if (elem[i] == ge)
		{
			elem[i].setName(name);
			elem[i].setNOS(nos);
			elem[i].setNOR(nor);
			elem[i].setWeight(weight);

			return;
		}
	}
}

bool Repo::findElem(GymExercise ge)
{
	vector<GymExercise>::iterator it;
	it = find(elem.begin(), elem.end(), ge);
		if (it != elem.end()) return true;
	return false;
}

GymExercise Repo::getItemFromPos(int pos)
{
	
		return elem[pos];
}


vector<GymExercise> Repo::getAll()
{
	return elem;
}
int Repo::getSize()
{
	return elem.size();
}


Repo::~Repo(){}