#pragma once
#ifndef GYM_H
#define GYM_H


#include <iostream>
#include <string.h>
class GymExercise
{
private:
	char* name;
	int nos;
	int nor;
	float weight;
public:
	GymExercise();
	GymExercise(const char* n, int NOS, int NOR, float w);
	GymExercise(const GymExercise& ge);
	

	char* getName();
	int getNOS();
	int getNOR();
	float getWeight();

	void setName(const char* n);
	void setNOS(int n);
	void setNOR(int n);
	void setWeight(float n);

	GymExercise& operator = (const GymExercise& ge);
	bool operator == (const GymExercise& ge);
~GymExercise();

};



#endif // !GYM_H



