#pragma once
#include "Operations.h"
#include "GymExercise.h"
#include "Repo.h"
#include <assert.h>
#include "Test1.h"


void test_filter_by_x()
{
	GymExercise a1("flotari", 3, 5, 50.0);
	GymExercise a2("fandari", 2, 2, 10.0);
	GymExercise a3("flotari", 4, 10, 2.2);
	GymExercise a4("asda", 5, 12, 3.2);

	GymExercise ex[4] = { a1,a2,a3,a4 };
	GymExercise result[4];
	int m = 0;

	filter_by_x(ex, 4, 45, result, m);

	assert(m == 3);
	assert(result[0] == a1);
	assert(result[1] == a3);
	assert(result[2] == a4);


}

void test_delete_by_weight()
{

	GymExercise a1("flotari", 3, 3, 1);
	GymExercise a2("fandari", 2, 2, 2);
	GymExercise a3("flotari", 4, 10, 2.2);
	GymExercise a4("asda", 5, 12, 3.2);

	GymExercise ex[4] = { a1,a2,a3,a4 };

	Repo rep;
	rep.addItem(a1);
	rep.addItem(a2);
	rep.addItem(a3);
	rep.addItem(a4);

	GymExercise result[4];
	int m = 0;

	delete_by_weight(rep, result, m);

	assert(m == 2);
	assert(result[0] == a1);
	assert(result[1] == a2);



}