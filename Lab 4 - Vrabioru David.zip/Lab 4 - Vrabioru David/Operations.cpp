#include <openservice.h>
#include "GymExercise.h"
#include "Repo.h"




/*
functia filtreaza toate exercitiile care au nos*nor*weight > x 
in: an array of GymExercise and their number(int), an float number x, an empty array and his new length
out: an array of GymExercise and their number
*/
void filter_by_x(GymExercise ge[], int n, float x, GymExercise ge_filtered[], int& m)
{
	m = 0;
	for(int i=0;i<n;i++)
		if (ge[i].getNOS() * ge[i].getNOR() * ge[i].getWeight() > x)
		{
			
			ge_filtered[m] = ge[i];
			m++;
		}
}

void delete_by_weight(Repo &rep, GymExercise ge_filtered[], int &m)
{
	m = 0;
	for (int i = 0; i < rep.getSize(); i++)
	{
		GymExercise crtGymExercise = rep.getItemFromPos(i);
		
		if (crtGymExercise.getWeight() * crtGymExercise.getNOR() < 5.0)
		{
				
				ge_filtered[m++] = crtGymExercise;
		}
		else rep.delElem(crtGymExercise);
			
	}

}