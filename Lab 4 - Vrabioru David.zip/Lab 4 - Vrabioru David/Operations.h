#pragma once
#include "GymExercise.h"
#include "Repo.h"

void filter_by_x(GymExercise ge[], int n, int x, GymExercise ge_filtered[], int& m);
void delete_by_weight(Repo& rep , GymExercise ge_filtered[], int &m);