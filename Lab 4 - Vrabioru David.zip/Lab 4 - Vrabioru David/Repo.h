#pragma once
#ifndef REPO_H
#define REPO_H
#include "GymExercise.h"
#include <vector>
using namespace std;

class Repo
{
private:
	vector<GymExercise> elem;
public:
	Repo();

	void addItem(GymExercise);
	bool findElem(GymExercise);
	void delElem(GymExercise);
	void updateElem(GymExercise, char*, int, int, float);
	GymExercise getItemFromPos(int);
	vector< GymExercise> getAll();
	int getSize();

	~Repo();



};

#endif // !REPO_H

