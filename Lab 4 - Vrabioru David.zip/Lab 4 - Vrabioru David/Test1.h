#pragma once


void test_filter_by_x();
void test_delete_by_weight();