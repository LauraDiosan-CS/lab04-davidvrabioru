
#include <iostream>
#include "Test1.h"
using namespace std;

int main()
{
    cout << "start..."<<endl;
    test_delete_by_weight();
    test_filter_by_x();
    cout << "Succes! ";
}

