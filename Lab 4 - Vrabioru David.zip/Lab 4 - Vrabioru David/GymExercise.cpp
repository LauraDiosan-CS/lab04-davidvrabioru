#include "GymExercise.h"
#include <iostream>
#include <string.h>

GymExercise::GymExercise()
{
	this->name = NULL;
	this->nos = 0;
	this->nor = 0;
	this->weight = 0.0;
}

GymExercise::GymExercise(const char* n, int NOS, int NOR, float w)
{
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, sizeof this->name, n);
	this->nos = NOS;
	this->nor = NOR;
	this->weight = w;
}

GymExercise::GymExercise(const GymExercise& ge)
{
	this->name = new char[strlen(ge.name) + 1];
	strcpy_s(this->name, sizeof this->name, ge.name);
	this->nos = ge.nos;
	this->nor = ge.nor;
	this->weight = ge.weight;
}



char* GymExercise::getName() {
	return this->name;
}

int GymExercise::getNOS()
{
	return this->nos;
}

int GymExercise::getNOR()
{
	return this->nor;
}

float GymExercise::getWeight()
{
	return this->weight;
}

void GymExercise::setName(const char* n)
{
	if (this->name) {
		delete[] this->name;
	}
	this->name = new char[strlen(n) + 1];
	strcpy_s(this->name, sizeof this->name, n);

}

void GymExercise::setNOS(int n)
{
	this->nos = n;
}

void GymExercise::setNOR(int n)
{
	this->nor = n;
}

void GymExercise::setWeight(float n)
{
	this->weight = n;
}

GymExercise& GymExercise::operator = (const GymExercise& ge) {
	this->setName(ge.name);
	this->setNOS(ge.nos);
	this->setNOR(ge.nor);
	this->setWeight(ge.weight);
	return *this;
}

bool GymExercise::operator == (const GymExercise& ge) {
	return(strcmp(this->name, ge.name) == 0 && this->nos == ge.nos && this->nor == ge.nor && this->weight == ge.weight);
}


GymExercise::~GymExercise() {
	if (this->name) {
		delete[] this->name;
		this->name = NULL;
	}
}